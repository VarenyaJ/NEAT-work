#!/usr/bin/env python3

from .cli import run
run()
