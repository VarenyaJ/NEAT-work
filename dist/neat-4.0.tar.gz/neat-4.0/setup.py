# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['neat',
 'neat.cli',
 'neat.cli.commands',
 'neat.common',
 'neat.compute_fraglen',
 'neat.models',
 'neat.read_simulator',
 'neat.read_simulator.utils',
 'neat.utilities']

package_data = \
{'': ['*'], 'neat.models': ['defaults/*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'biopython==1.79',
 'matplotlib>=3.5,<4.0',
 'numpy>=1.23,<2.0',
 'pybedtools>=0.9.0,<0.10.0',
 'pysam>=0.19.1,<0.20.0']

entry_points = \
{'console_scripts': ['neat = neat.cli.cli:run']}

setup_kwargs = {
    'name': 'neat',
    'version': '4.0',
    'description': 'NGS Simulation toolkit',
    'long_description': None,
    'author': 'Joshua Allen',
    'author_email': 'jallen17@illinois.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
